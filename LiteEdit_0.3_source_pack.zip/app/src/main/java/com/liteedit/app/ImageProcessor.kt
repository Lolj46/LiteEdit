package com.liteedit.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.graphics.ImageDecoder
import android.util.Log
import java.io.IOException
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Bitmap decoding and rendering. No third-party image libraries are used. */
object ImageProcessor {

    private const val TAG = "LiteEditImage"
    const val MAX_EXPORT_EDGE = 5000
    const val MAX_EXPORT_PIXELS = 10_000_000L

    /** Returns the image dimensions after applying the EXIF orientation. */
    fun readOriginalDimensions(context: Context, uri: Uri): Pair<Int, Int> {
        val options = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }

        context.contentResolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, options)
        } ?: throw IOException("Не удалось прочитать файл изображения")

        if (options.outWidth <= 0 || options.outHeight <= 0) {
            throw IOException("Не удалось определить размеры изображения")
        }

        val orientation = readExifOrientation(context, uri)
        val swapsSides = orientation == ExifInterface.ORIENTATION_ROTATE_90 ||
            orientation == ExifInterface.ORIENTATION_ROTATE_270 ||
            orientation == ExifInterface.ORIENTATION_TRANSPOSE ||
            orientation == ExifInterface.ORIENTATION_TRANSVERSE

        return if (swapsSides) {
            Pair(options.outHeight, options.outWidth)
        } else {
            Pair(options.outWidth, options.outHeight)
        }
    }

    /**
     * Decodes an image to a bounded bitmap. maxPixels is a hard output-pixel budget;
     * this keeps previews and exports from creating unexpectedly huge allocations.
     */
    fun decode(
        context: Context,
        uri: Uri,
        maxEdge: Int,
        maxPixels: Long
    ): Bitmap {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                return decodeWithImageDecoder(context, uri, maxEdge, maxPixels)
            } catch (e: Exception) {
                Log.w(TAG, "ImageDecoder failed; using BitmapFactory fallback", e)
            }
        }
        return decodeWithBitmapFactory(context, uri, maxEdge, maxPixels)
    }

    private fun decodeWithImageDecoder(
        context: Context,
        uri: Uri,
        maxEdge: Int,
        maxPixels: Long
    ): Bitmap {
        val source = ImageDecoder.createSource(context.contentResolver, uri)

        return ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            val target = calculateTargetSize(
                info.size.width,
                info.size.height,
                maxEdge,
                maxPixels
            )
            decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE)
            decoder.setMutableRequired(false)
            decoder.setTargetSize(target.first, target.second)
        }
    }

    @Suppress("DEPRECATION")
    private fun decodeWithBitmapFactory(
        context: Context,
        uri: Uri,
        maxEdge: Int,
        maxPixels: Long
    ): Bitmap {
        val bounds = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }

        context.contentResolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, bounds)
        } ?: throw IOException("Не удалось открыть изображение")

        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw IOException("Неподдерживаемый или повреждённый файл")
        }

        val target = calculateTargetSize(
            bounds.outWidth,
            bounds.outHeight,
            maxEdge,
            maxPixels
        )

        var sampleSize = 1
        while (
            bounds.outWidth / (sampleSize * 2) >= target.first &&
            bounds.outHeight / (sampleSize * 2) >= target.second
        ) {
            sampleSize *= 2
        }

        val options = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }

        var bitmap = context.contentResolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, options)
        } ?: throw IOException("Не удалось декодировать изображение")

        bitmap = applyExifOrientation(
            bitmap,
            readExifOrientation(context, uri)
        )

        val orientedTarget = calculateTargetSize(
            bitmap.width,
            bitmap.height,
            maxEdge,
            maxPixels
        )

        if (
            bitmap.width > orientedTarget.first ||
            bitmap.height > orientedTarget.second
        ) {
            val scaled = Bitmap.createScaledBitmap(
                bitmap,
                orientedTarget.first,
                orientedTarget.second,
                true
            )
            if (scaled !== bitmap) bitmap.recycle()
            bitmap = scaled
        }

        return bitmap
    }

    private fun calculateTargetSize(
        width: Int,
        height: Int,
        maxEdge: Int,
        maxPixels: Long
    ): Pair<Int, Int> {
        if (width <= 0 || height <= 0) {
            throw IOException("Некорректные размеры изображения")
        }

        var scale = 1.0
        if (maxEdge > 0) {
            scale = min(scale, maxEdge.toDouble() / max(width, height).toDouble())
        }

        val pixels = width.toDouble() * height.toDouble()
        if (maxPixels > 0 && pixels * scale * scale > maxPixels.toDouble()) {
            scale = min(scale, sqrt(maxPixels.toDouble() / pixels))
        }

        return Pair(
            max(1, (width * scale).roundToInt()),
            max(1, (height * scale).roundToInt())
        )
    }

    private fun readExifOrientation(context: Context, uri: Uri): Int {
        return try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                ExifInterface(stream).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            Log.w(TAG, "Could not read EXIF orientation", e)
            ExifInterface.ORIENTATION_NORMAL
        }
    }

    private fun applyExifOrientation(bitmap: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.setScale(-1f, 1f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.setRotate(180f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.setScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> {
                matrix.setRotate(90f)
                matrix.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.setRotate(90f)
            ExifInterface.ORIENTATION_TRANSVERSE -> {
                matrix.setRotate(270f)
                matrix.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.setRotate(270f)
            else -> return bitmap
        }

        val result = Bitmap.createBitmap(
            bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true
        )
        if (result !== bitmap) bitmap.recycle()
        return result
    }

    /** Renders a non-destructive EditState into a new bounded bitmap. */
    fun render(
        source: Bitmap,
        state: EditState,
        maxEdge: Int = MAX_EXPORT_EDGE,
        maxPixels: Long = MAX_EXPORT_PIXELS
    ): Bitmap {
        var transformed = source

        val rotation = ((state.rotation % 360) + 360) % 360
        if (rotation != 0 || state.flipHorizontal || state.flipVertical) {
            val matrix = Matrix()
            if (rotation != 0) matrix.postRotate(rotation.toFloat())
            if (state.flipHorizontal || state.flipVertical) {
                matrix.postScale(
                    if (state.flipHorizontal) -1f else 1f,
                    if (state.flipVertical) -1f else 1f
                )
            }
            transformed = Bitmap.createBitmap(
                source, 0, 0, source.width, source.height, matrix, true
            )
        }

        val leftFraction = state.cropLeft.coerceIn(0f, 0.99f)
        val topFraction = state.cropTop.coerceIn(0f, 0.99f)
        val widthFraction = state.cropWidth.coerceIn(0.01f, 1f - leftFraction)
        val heightFraction = state.cropHeight.coerceIn(0.01f, 1f - topFraction)

        val cropLeft = (leftFraction * transformed.width).roundToInt()
            .coerceIn(0, transformed.width - 1)
        val cropTop = (topFraction * transformed.height).roundToInt()
            .coerceIn(0, transformed.height - 1)
        val cropWidth = (widthFraction * transformed.width).roundToInt()
            .coerceIn(1, transformed.width - cropLeft)
        val cropHeight = (heightFraction * transformed.height).roundToInt()
            .coerceIn(1, transformed.height - cropTop)

        val cropped = if (
            cropLeft == 0 && cropTop == 0 &&
            cropWidth == transformed.width && cropHeight == transformed.height
        ) {
            transformed
        } else {
            Bitmap.createBitmap(
                transformed,
                cropLeft,
                cropTop,
                cropWidth,
                cropHeight
            )
        }

        val requestedWidth = if (state.outputWidth > 0) {
            state.outputWidth
        } else {
            cropped.width
        }
        val requestedHeight = if (state.outputHeight > 0) {
            state.outputHeight
        } else {
            cropped.height
        }

        val target = calculateTargetSize(
            requestedWidth,
            requestedHeight,
            maxEdge,
            maxPixels
        )
        val outputWidth = target.first
        val outputHeight = target.second

        val hasColorChanges = state.brightness != 0 ||
            state.contrast != 100 || state.saturation != 100
        val hasOtherChanges = hasColorChanges || state.blur > 0 || state.text.isNotBlank()
        val noGeometryChanges = rotation == 0 &&
            !state.flipHorizontal && !state.flipVertical &&
            cropLeft == 0 && cropTop == 0 &&
            cropWidth == source.width && cropHeight == source.height

        if (
            !hasOtherChanges && noGeometryChanges &&
            outputWidth == source.width && outputHeight == source.height
        ) {
            return source
        }

        val output = Bitmap.createBitmap(
            outputWidth,
            outputHeight,
            Bitmap.Config.ARGB_8888
        )

        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        if (hasColorChanges) {
            paint.colorFilter = createColorFilter(state)
        }

        Canvas(output).drawBitmap(
            cropped,
            null as Rect?,
            Rect(0, 0, outputWidth, outputHeight),
            paint
        )

        if (state.blur > 0) {
            applyFastBlur(output, state.blur.coerceIn(1, 12))
        }

        if (state.text.isNotBlank()) {
            drawTextOverlay(output, state.text)
        }

        // Intermediate transformed/cropped bitmaps are left to GC. They can share
        // pixel storage with their source, so recycling them here is unsafe.
        return output
    }

    private fun createColorFilter(state: EditState): ColorMatrixColorFilter {
        val contrast = (state.contrast.coerceIn(0, 200) / 100f)
        val brightness = state.brightness.coerceIn(-100, 100) * 2.55f
        val offset = brightness + 128f * (1f - contrast)

        val brightnessContrast = ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, offset,
                0f, contrast, 0f, 0f, offset,
                0f, 0f, contrast, 0f, offset,
                0f, 0f, 0f, 1f, 0f
            )
        )

        val saturation = ColorMatrix().apply {
            setSaturation(state.saturation.coerceIn(0, 200) / 100f)
        }

        val combined = ColorMatrix()
        combined.setConcat(saturation, brightnessContrast)
        return ColorMatrixColorFilter(combined)
    }

    /** A separable box blur. Uses one pixel array plus a reusable scanline buffer. */
    private fun applyFastBlur(bitmap: Bitmap, radius: Int) {
        val width = bitmap.width
        val height = bitmap.height
        if (width < 2 || height < 2 || radius <= 0) return

        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        val line = IntArray(max(width, height))

        // Horizontal pass. Copy each source row before writing over it.
        for (y in 0 until height) {
            val rowStart = y * width
            System.arraycopy(pixels, rowStart, line, 0, width)

            var sumA = 0
            var sumR = 0
            var sumG = 0
            var sumB = 0
            var count = 0
            val initialEnd = min(width - 1, radius)
            for (i in 0..initialEnd) {
                val c = line[i]
                sumA += Color.alpha(c)
                sumR += Color.red(c)
                sumG += Color.green(c)
                sumB += Color.blue(c)
                count++
            }

            for (x in 0 until width) {
                pixels[rowStart + x] = Color.argb(
                    sumA / count, sumR / count, sumG / count, sumB / count
                )

                val removeIndex = x - radius
                if (removeIndex >= 0) {
                    val c = line[removeIndex]
                    sumA -= Color.alpha(c)
                    sumR -= Color.red(c)
                    sumG -= Color.green(c)
                    sumB -= Color.blue(c)
                    count--
                }

                val addIndex = x + radius + 1
                if (addIndex < width) {
                    val c = line[addIndex]
                    sumA += Color.alpha(c)
                    sumR += Color.red(c)
                    sumG += Color.green(c)
                    sumB += Color.blue(c)
                    count++
                }
            }
        }

        // Vertical pass. Copy each source column before writing over it.
        for (x in 0 until width) {
            for (y in 0 until height) {
                line[y] = pixels[y * width + x]
            }

            var sumA = 0
            var sumR = 0
            var sumG = 0
            var sumB = 0
            var count = 0
            val initialEnd = min(height - 1, radius)
            for (i in 0..initialEnd) {
                val c = line[i]
                sumA += Color.alpha(c)
                sumR += Color.red(c)
                sumG += Color.green(c)
                sumB += Color.blue(c)
                count++
            }

            for (y in 0 until height) {
                pixels[y * width + x] = Color.argb(
                    sumA / count, sumR / count, sumG / count, sumB / count
                )

                val removeIndex = y - radius
                if (removeIndex >= 0) {
                    val c = line[removeIndex]
                    sumA -= Color.alpha(c)
                    sumR -= Color.red(c)
                    sumG -= Color.green(c)
                    sumB -= Color.blue(c)
                    count--
                }

                val addIndex = y + radius + 1
                if (addIndex < height) {
                    val c = line[addIndex]
                    sumA += Color.alpha(c)
                    sumR += Color.red(c)
                    sumG += Color.green(c)
                    sumB += Color.blue(c)
                    count++
                }
            }
        }

        bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
    }

    private fun drawTextOverlay(bitmap: Bitmap, text: String) {
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textSize = max(22f, min(bitmap.width, bitmap.height) * 0.055f)
            setShadowLayer(4f, 1f, 2f, Color.BLACK)
        }

        val safeText = text.take(120)
        val x = bitmap.width / 2f
        val y = bitmap.height * 0.88f
        canvas.drawText(safeText, x, y, paint)
    }
}
