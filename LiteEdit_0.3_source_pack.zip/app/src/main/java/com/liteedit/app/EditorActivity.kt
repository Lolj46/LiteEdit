package com.liteedit.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.text.InputType
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class EditorActivity : Activity() {

    companion object {
        private const val REQUEST_CREATE_EXPORT = 2002
        private const val PREVIEW_MAX_EDGE = 1600
        private const val PREVIEW_MAX_PIXELS = 2_560_000L
    }

    private val imageExecutor = Executors.newSingleThreadExecutor()
    private val history = HistoryManager(30)

    private lateinit var imageView: ImageView
    private lateinit var statusText: TextView
    private lateinit var sourceUri: Uri

    private var sourceBitmap: Bitmap? = null
    private var state = EditState()
    private var originalWidth = 0
    private var originalHeight = 0
    @Volatile
    private var renderGeneration = 0
    private var pendingMimeType = "image/jpeg"
    private var pendingQuality = 92

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val uriText = intent.getStringExtra("image_uri")
        if (uriText.isNullOrBlank()) {
            Toast.makeText(this, "Изображение не передано", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        sourceUri = Uri.parse(uriText)
        window.statusBarColor = Color.rgb(16, 17, 13)
        window.navigationBarColor = Color.rgb(16, 17, 13)

        buildInterface()
        loadSourceImage()
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(16, 17, 13))
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val title = TextView(this).apply {
            text = "LiteEdit  /  РЕДАКТОР"
            textSize = 17f
            setTextColor(Color.rgb(240, 240, 232))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        header.addView(
            title,
            LinearLayout.LayoutParams(0, dp(48), 1f)
        )
        header.addView(makeButton("Экспорт") { chooseExportFormat() })
        root.addView(header)

        val previewFrame = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(28, 30, 23))
        }
        imageView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Предпросмотр редактируемого изображения"
        }
        previewFrame.addView(
            imageView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )
        root.addView(
            previewFrame,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            ).apply {
                topMargin = dp(8)
                bottomMargin = dp(8)
            }
        )

        statusText = TextView(this).apply {
            text = "Подготовка изображения..."
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(155, 158, 143))
            setPadding(dp(4), dp(5), dp(4), dp(5))
        }
        root.addView(statusText)

        val toolsScroll = ScrollView(this).apply {
            isFillViewport = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        addToolRow(
            tools,
            Pair("Обрезка", ::showCropDialog),
            Pair("Поворот", ::rotateImage),
            Pair("Отразить ↔", ::flipHorizontal),
            Pair("Отразить ↕", ::flipVertical)
        )
        addToolRow(
            tools,
            Pair("Цвет", ::showAdjustDialog),
            Pair("Размытие", ::showBlurDialog),
            Pair("Текст", ::showTextDialog),
            Pair("Размер", ::showResizeDialog)
        )
        addToolRow(
            tools,
            Pair("Отмена", ::undo),
            Pair("Повтор", ::redo),
            Pair("Сброс", ::confirmReset),
            Pair("Сохранить", ::chooseExportFormat)
        )

        toolsScroll.addView(tools)
        root.addView(
            toolsScroll,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        setContentView(root)
    }

    private fun addToolRow(
        parent: LinearLayout,
        vararg items: Pair<String, () -> Unit>
    ) {
        val horizontalScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        items.forEach { item ->
            row.addView(makeButton(item.first, item.second))
        }

        horizontalScroll.addView(row)
        parent.addView(horizontalScroll)
    }

    private fun makeButton(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 12f
            minWidth = dp(76)
            setTextColor(Color.rgb(239, 240, 231))
            backgroundTintList = ColorStateList.valueOf(Color.rgb(48, 51, 39))
            setPadding(dp(8), 0, dp(8), 0)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                dp(44)
            ).apply {
                setMargins(dp(3), dp(3), dp(3), dp(3))
            }
            setOnClickListener { action() }
        }
    }

    private fun loadSourceImage() {
        statusText.text = "Загрузка изображения..."

        imageExecutor.execute {
            try {
                val dimensions = ImageProcessor.readOriginalDimensions(this, sourceUri)
                val decoded = ImageProcessor.decode(
                    this,
                    sourceUri,
                    PREVIEW_MAX_EDGE,
                    PREVIEW_MAX_PIXELS
                )

                runOnUiThread {
                    if (isFinishing || isDestroyed) {
                        decoded.recycle()
                        return@runOnUiThread
                    }
                    originalWidth = dimensions.first
                    originalHeight = dimensions.second
                    sourceBitmap = decoded
                    statusText.text = "Оригинал: ${originalWidth} × ${originalHeight}"
                    renderPreview()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    statusText.text = "Не удалось загрузить: ${e.message ?: e.javaClass.simpleName}"
                    Toast.makeText(
                        this,
                        "Ошибка открытия изображения",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (e: OutOfMemoryError) {
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    statusText.text = "Недостаточно памяти для предпросмотра"
                }
            }
        }
    }

    private fun renderPreview() {
        val source = sourceBitmap ?: return
        val snapshot = state.copy()
        val generation = ++renderGeneration
        statusText.text = "Обновление предпросмотра..."

        imageExecutor.execute {
            if (generation != renderGeneration) return@execute
            var rendered: Bitmap? = null
            try {
                rendered = ImageProcessor.render(
                    source,
                    snapshot,
                    PREVIEW_MAX_EDGE,
                    PREVIEW_MAX_PIXELS
                )

                runOnUiThread {
                    if (
                        isFinishing || isDestroyed ||
                        generation != renderGeneration
                    ) {
                        if (rendered !== source && rendered != null && !rendered.isRecycled) {
                            rendered.recycle()
                        }
                        return@runOnUiThread
                    }

                    imageView.setImageBitmap(rendered)
                    statusText.text = "Предпросмотр · ${rendered.width} × ${rendered.height}"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (generation != renderGeneration || isFinishing || isDestroyed) {
                        return@runOnUiThread
                    }
                    statusText.text = "Ошибка обработки: ${e.message ?: e.javaClass.simpleName}"
                }
            } catch (e: OutOfMemoryError) {
                runOnUiThread {
                    if (generation != renderGeneration || isFinishing || isDestroyed) {
                        return@runOnUiThread
                    }
                    statusText.text = "Недостаточно памяти для эффекта"
                }
            }
        }
    }

    private fun updateState(newState: EditState) {
        history.record(state)
        state = newState
        renderPreview()
    }

    private fun rotateImage() {
        updateState(state.copy(rotation = (state.rotation + 90) % 360))
    }

    private fun flipHorizontal() {
        updateState(state.copy(flipHorizontal = !state.flipHorizontal))
    }

    private fun flipVertical() {
        updateState(state.copy(flipVertical = !state.flipVertical))
    }

    private fun undo() {
        val previous = history.undo(state)
        if (previous == null) {
            showToast("Нечего отменять")
        } else {
            state = previous
            renderPreview()
        }
    }

    private fun redo() {
        val next = history.redo(state)
        if (next == null) {
            showToast("Нечего повторять")
        } else {
            state = next
            renderPreview()
        }
    }

    private fun confirmReset() {
        AlertDialog.Builder(this)
            .setTitle("Сбросить изменения?")
            .setMessage("Все настройки редактирования вернутся к исходным значениям.")
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Сбросить") { _, _ ->
                updateState(EditState())
            }
            .show()
    }

    private fun showCropDialog() {
        val content = makeDialogContent()
        val leftInput = addNumberField(content, "Слева, %", percent(state.cropLeft))
        val topInput = addNumberField(content, "Сверху, %", percent(state.cropTop))
        val widthInput = addNumberField(content, "Ширина, %", percent(state.cropWidth))
        val heightInput = addNumberField(content, "Высота, %", percent(state.cropHeight))

        AlertDialog.Builder(this)
            .setTitle("Обрезка изображения")
            .setMessage("Укажи область в процентах от изображения после поворота.")
            .setView(content)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Применить") { _, _ ->
                val left = number(leftInput, 0f) / 100f
                val top = number(topInput, 0f) / 100f
                val width = number(widthInput, 100f) / 100f
                val height = number(heightInput, 100f) / 100f

                if (
                    left < 0f || top < 0f || width <= 0f || height <= 0f ||
                    left >= 1f || top >= 1f ||
                    left + width > 1.001f || top + height > 1.001f
                ) {
                    showToast("Область обрезки выходит за границы изображения")
                    return@setPositiveButton
                }

                updateState(
                    state.copy(
                        cropLeft = left.coerceIn(0f, 0.99f),
                        cropTop = top.coerceIn(0f, 0.99f),
                        cropWidth = width.coerceIn(0.01f, 1f - left),
                        cropHeight = height.coerceIn(0.01f, 1f - top),
                        outputWidth = 0,
                        outputHeight = 0
                    )
                )
            }
            .show()
    }

    private fun showResizeDialog() {
        val base = currentCroppedDimensions()
        val initial = fitDimensions(
            if (state.outputWidth > 0) state.outputWidth else base.first,
            if (state.outputHeight > 0) state.outputHeight else base.second
        )

        val content = makeDialogContent()
        val widthInput = addNumberField(content, "Ширина, px", initial.first.toString())
        val heightInput = addNumberField(content, "Высота, px", initial.second.toString())

        AlertDialog.Builder(this)
            .setTitle("Изменить размер")
            .setMessage("Максимум: 5000 px по стороне и 10 мегапикселей суммарно.")
            .setView(content)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Применить") { _, _ ->
                val width = widthInput.text.toString().toIntOrNull() ?: 0
                val height = heightInput.text.toString().toIntOrNull() ?: 0

                if (
                    width !in 1..ImageProcessor.MAX_EXPORT_EDGE ||
                    height !in 1..ImageProcessor.MAX_EXPORT_EDGE ||
                    width.toLong() * height.toLong() > ImageProcessor.MAX_EXPORT_PIXELS
                ) {
                    showToast("Размеры превышают безопасный предел")
                    return@setPositiveButton
                }

                updateState(state.copy(outputWidth = width, outputHeight = height))
            }
            .show()
    }

    private fun currentCroppedDimensions(): Pair<Int, Int> {
        val rotated = state.rotation % 180 != 0
        val baseWidth = if (rotated) originalHeight else originalWidth
        val baseHeight = if (rotated) originalWidth else originalHeight
        val width = max(1, (baseWidth * state.cropWidth).roundToInt())
        val height = max(1, (baseHeight * state.cropHeight).roundToInt())
        return Pair(width, height)
    }

    private fun fitDimensions(width: Int, height: Int): Pair<Int, Int> {
        val scaleByEdge = min(
            1.0,
            ImageProcessor.MAX_EXPORT_EDGE.toDouble() / max(width, height).toDouble()
        )
        val pixels = width.toDouble() * height.toDouble()
        val scaleByPixels = if (pixels > ImageProcessor.MAX_EXPORT_PIXELS) {
            kotlin.math.sqrt(ImageProcessor.MAX_EXPORT_PIXELS.toDouble() / pixels)
        } else {
            1.0
        }
        val scale = min(scaleByEdge, scaleByPixels)
        return Pair(
            max(1, (width * scale).roundToInt()),
            max(1, (height * scale).roundToInt())
        )
    }

    private fun showAdjustDialog() {
        val content = makeDialogContent()
        val brightnessLabel = addSectionLabel(content, "Яркость: ${state.brightness}")
        val brightness = addSeekBar(content, 200, state.brightness + 100) { value ->
            brightnessLabel.text = "Яркость: ${value - 100}"
        }
        val contrastLabel = addSectionLabel(content, "Контраст: ${state.contrast}%")
        val contrast = addSeekBar(content, 200, state.contrast) { value ->
            contrastLabel.text = "Контраст: $value%"
        }
        val saturationLabel = addSectionLabel(content, "Насыщенность: ${state.saturation}%")
        val saturation = addSeekBar(content, 200, state.saturation) { value ->
            saturationLabel.text = "Насыщенность: $value%"
        }

        AlertDialog.Builder(this)
            .setTitle("Настройка цвета")
            .setView(content)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Применить") { _, _ ->
                updateState(
                    state.copy(
                        brightness = brightness.progress - 100,
                        contrast = contrast.progress,
                        saturation = saturation.progress
                    )
                )
            }
            .show()
    }

    private fun showBlurDialog() {
        val content = makeDialogContent()
        val label = addSectionLabel(content, "Сила размытия: ${state.blur}")
        val seek = addSeekBar(content, 12, state.blur) { value ->
            label.text = "Сила размытия: $value"
        }

        AlertDialog.Builder(this)
            .setTitle("Размытие")
            .setMessage("Размытие применяется к изображению; текстовый слой остаётся чётким.")
            .setView(content)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Применить") { _, _ ->
                updateState(state.copy(blur = seek.progress))
            }
            .show()
    }

    private fun showTextDialog() {
        val content = makeDialogContent()
        val input = EditText(this).apply {
            setText(state.text)
            hint = "Текст на изображении"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            minLines = 2
            maxLines = 3
        }
        content.addView(input)

        AlertDialog.Builder(this)
            .setTitle("Текст на изображении")
            .setMessage("Текст размещается по центру ближе к нижнему краю.")
            .setView(content)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Применить") { _, _ ->
                updateState(state.copy(text = input.text.toString().take(120)))
            }
            .show()
    }

    private fun chooseExportFormat() {
        val formats = arrayOf("JPEG · меньше размер файла", "PNG · без потерь")
        AlertDialog.Builder(this)
            .setTitle("Формат экспорта")
            .setItems(formats) { _, which ->
                if (which == 0) {
                    showJpegQualityDialog()
                } else {
                    beginExport("image/png", 100)
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showJpegQualityDialog() {
        val content = makeDialogContent()
        val label = addSectionLabel(content, "Качество JPEG: 92%")
        val seek = addSeekBar(content, 100, 92) { value ->
            label.text = "Качество JPEG: $value%"
        }

        AlertDialog.Builder(this)
            .setTitle("Качество изображения")
            .setMessage("Больше качество обычно означает больший размер файла.")
            .setView(content)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Продолжить") { _, _ ->
                beginExport("image/jpeg", seek.progress.coerceAtLeast(1))
            }
            .show()
    }

    private fun beginExport(mimeType: String, quality: Int) {
        pendingMimeType = mimeType
        pendingQuality = quality

        // Android 10+ lets the app save its own image to Pictures without storage permission.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            exportDirectlyToGallery(mimeType, quality)
            return
        }

        val extension = if (mimeType == "image/png") "png" else "jpg"
        val createIntent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mimeType
            putExtra(
                Intent.EXTRA_TITLE,
                "LiteEdit_${System.currentTimeMillis()}.$extension"
            )
        }

        try {
            startActivityForResult(createIntent, REQUEST_CREATE_EXPORT)
        } catch (e: Exception) {
            showToast("Не удалось открыть окно сохранения")
        }
    }


    private fun exportDirectlyToGallery(mimeType: String, quality: Int) {
        val currentSource = sourceUri
        val editSnapshot = state.copy()
        statusText.text = "Экспорт в Pictures/LiteEdit..."

        imageExecutor.execute {
            try {
                ImageExporter.exportToGallery(
                    this,
                    currentSource,
                    editSnapshot,
                    mimeType,
                    quality
                )

                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    statusText.text = "Сохранено в Pictures/LiteEdit"
                    showToast("Изображение сохранено в галерею")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    statusText.text = "Ошибка экспорта: ${e.message ?: e.javaClass.simpleName}"
                    showToast("Не удалось сохранить изображение")
                }
            } catch (e: OutOfMemoryError) {
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    statusText.text = "Недостаточно памяти для экспорта"
                    showToast("Изображение слишком большое для этого устройства")
                }
            }
        }
    }

    @Deprecated("Используется для совместимости с минимальным SDK 26")
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode != REQUEST_CREATE_EXPORT || resultCode != RESULT_OK) {
            return
        }

        val destination = data?.data
        if (destination == null) {
            showToast("Не выбрано место сохранения")
            return
        }

        val currentSource = sourceUri
        val editSnapshot = state.copy()
        val mime = pendingMimeType
        val quality = pendingQuality

        statusText.text = "Экспорт изображения..."
        imageExecutor.execute {
            try {
                ImageExporter.exportToUri(
                    this,
                    currentSource,
                    destination,
                    editSnapshot,
                    mime,
                    quality
                )

                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    statusText.text = "Изображение сохранено"
                    showToast("Изображение успешно сохранено")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    statusText.text = "Ошибка экспорта: ${e.message ?: e.javaClass.simpleName}"
                    showToast("Не удалось сохранить изображение")
                }
            } catch (e: OutOfMemoryError) {
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    statusText.text = "Недостаточно памяти для экспорта"
                    showToast("Изображение слишком большое для этого устройства")
                }
            }
        }
    }

    private fun makeDialogContent(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(4))
        }
    }

    private fun addNumberField(
        parent: LinearLayout,
        label: String,
        value: String
    ): EditText {
        val labelView = TextView(this).apply {
            text = label
            textSize = 13f
            setTextColor(Color.LTGRAY)
        }
        parent.addView(labelView)

        val input = EditText(this).apply {
            setText(value)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            singleLine = true
        }
        parent.addView(
            input,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(46)
            )
        )
        return input
    }

    private fun addSectionLabel(parent: LinearLayout, text: String): TextView {
        val label = TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(7), 0, 0)
        }
        parent.addView(label)
        return label
    }

    private fun addSeekBar(
        parent: LinearLayout,
        maxValue: Int,
        initialValue: Int,
        onValueChanged: (Int) -> Unit
    ): SeekBar {
        val seek = SeekBar(this).apply {
            max = maxValue
            progress = initialValue.coerceIn(0, maxValue)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                    onValueChanged(progress)
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        }
        parent.addView(seek)
        return seek
    }

    private fun number(input: EditText, fallback: Float): Float {
        return input.text.toString().replace(',', '.').toFloatOrNull() ?: fallback
    }

    private fun percent(value: Float): String = (value * 100f).roundToInt().toString()

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    override fun onDestroy() {
        imageExecutor.shutdownNow()
        super.onDestroy()
    }
}
