package com.liteedit.app

/** Stores small immutable edit descriptions, never bitmap copies. */
class HistoryManager(private val maxEntries: Int = 30) {

    private val undoStack = mutableListOf<EditState>()
    private val redoStack = mutableListOf<EditState>()

    fun record(current: EditState) {
        undoStack.add(current.copy())
        if (undoStack.size > maxEntries) {
            undoStack.removeAt(0)
        }
        redoStack.clear()
    }

    fun undo(current: EditState): EditState? {
        if (undoStack.isEmpty()) return null
        redoStack.add(current.copy())
        return undoStack.removeAt(undoStack.lastIndex)
    }

    fun redo(current: EditState): EditState? {
        if (redoStack.isEmpty()) return null
        undoStack.add(current.copy())
        if (undoStack.size > maxEntries) {
            undoStack.removeAt(0)
        }
        return redoStack.removeAt(redoStack.lastIndex)
    }

    fun clear() {
        undoStack.clear()
        redoStack.clear()
    }

    fun canUndo(): Boolean = undoStack.isNotEmpty()
    fun canRedo(): Boolean = redoStack.isNotEmpty()
}
