package com.liteedit.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.LinearLayout
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        private const val REQUEST_PICK_IMAGE = 1001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = android.graphics.Color.rgb(16, 17, 13)
        window.navigationBarColor = android.graphics.Color.rgb(16, 17, 13)
        setContentView(R.layout.activity_main)

        findViewById<LinearLayout>(R.id.btnOpenImage).setOnClickListener {
            openImagePicker()
        }
    }

    private fun openImagePicker() {
        val pickerIntent = if (Build.VERSION.SDK_INT >= 33) {
            Intent(MediaStore.ACTION_PICK_IMAGES).apply {
                type = "image/*"
            }
        } else {
            Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
        }

        try {
            startActivityForResult(pickerIntent, REQUEST_PICK_IMAGE)
        } catch (e: ActivityNotFoundException) {
            val fallback = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "image/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            try {
                startActivityForResult(fallback, REQUEST_PICK_IMAGE)
            } catch (error: ActivityNotFoundException) {
                Toast.makeText(
                    this,
                    "Не удалось открыть галерею",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    @Deprecated("Используется для совместимости с минимальным SDK 26")
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode != REQUEST_PICK_IMAGE || resultCode != RESULT_OK) {
            return
        }

        val uri: Uri = data?.data ?: run {
            Toast.makeText(this, "Галерея не вернула изображение", Toast.LENGTH_SHORT).show()
            return
        }

        val flags = data.flags
        if (flags and Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION != 0) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // A temporary read grant is still enough for this editing session.
            }
        }

        val editorIntent = Intent(this, EditorActivity::class.java).apply {
            putExtra("image_uri", uri.toString())
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            clipData = ClipData.newRawUri("LiteEdit image", uri)
        }

        startActivity(editorIntent)
    }
}
