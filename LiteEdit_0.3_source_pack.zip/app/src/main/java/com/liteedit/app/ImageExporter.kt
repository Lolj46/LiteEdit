package com.liteedit.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.IOException

object ImageExporter {

    /** Exports the original source with the current non-destructive edit state. */
    fun exportToUri(
        context: Context,
        sourceUri: Uri,
        destinationUri: Uri,
        state: EditState,
        mimeType: String,
        quality: Int
    ) {
        val source = ImageProcessor.decode(
            context,
            sourceUri,
            ImageProcessor.MAX_EXPORT_EDGE,
            ImageProcessor.MAX_EXPORT_PIXELS
        )

        var rendered: Bitmap? = null

        try {
            rendered = ImageProcessor.render(
                source,
                state,
                ImageProcessor.MAX_EXPORT_EDGE,
                ImageProcessor.MAX_EXPORT_PIXELS
            )
            writeBitmap(context, destinationUri, rendered, mimeType, quality)
        } finally {
            if (rendered != null && rendered !== source && !rendered.isRecycled) {
                rendered.recycle()
            }
            if (!source.isRecycled) {
                source.recycle()
            }
        }
    }

    /** Saves directly to Pictures/LiteEdit on Android 10 and newer. */
    fun exportToGallery(
        context: Context,
        sourceUri: Uri,
        state: EditState,
        mimeType: String,
        quality: Int
    ): Uri {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            throw IllegalStateException("MediaStore export requires Android 10+")
        }

        val isPng = mimeType == "image/png"
        val extension = if (isPng) "png" else "jpg"
        val values = ContentValues().apply {
            put(
                MediaStore.Images.Media.DISPLAY_NAME,
                "LiteEdit_${System.currentTimeMillis()}.$extension"
            )
            put(MediaStore.Images.Media.MIME_TYPE, mimeType)
            put(
                MediaStore.Images.Media.RELATIVE_PATH,
                Environment.DIRECTORY_PICTURES + "/LiteEdit"
            )
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }

        val collection = MediaStore.Images.Media.getContentUri(
            MediaStore.VOLUME_EXTERNAL_PRIMARY
        )
        val destination = context.contentResolver.insert(collection, values)
            ?: throw IOException("Не удалось создать файл в галерее")

        try {
            exportToUri(
                context,
                sourceUri,
                destination,
                state,
                mimeType,
                quality
            )

            val completed = ContentValues().apply {
                put(MediaStore.Images.Media.IS_PENDING, 0)
            }
            context.contentResolver.update(destination, completed, null, null)
            return destination
        } catch (e: Exception) {
            context.contentResolver.delete(destination, null, null)
            throw e
        } catch (e: OutOfMemoryError) {
            context.contentResolver.delete(destination, null, null)
            throw e
        }
    }

    private fun writeBitmap(
        context: Context,
        destinationUri: Uri,
        bitmap: Bitmap,
        mimeType: String,
        quality: Int
    ) {
        val format = if (mimeType == "image/png") {
            Bitmap.CompressFormat.PNG
        } else {
            Bitmap.CompressFormat.JPEG
        }

        val output = context.contentResolver.openOutputStream(
            destinationUri,
            "w"
        ) ?: throw IOException("Не удалось открыть файл для записи")

        output.use { stream ->
            val saved = bitmap.compress(
                format,
                quality.coerceIn(1, 100),
                stream
            )
            if (!saved) {
                throw IOException("Не удалось записать изображение")
            }
            stream.flush()
        }
    }
}
