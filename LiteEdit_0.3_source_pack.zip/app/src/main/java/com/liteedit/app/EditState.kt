package com.liteedit.app

/**
 * Immutable description of edits. The original image is never modified.
 * Crop values are normalized fractions in the coordinate space after rotation/flipping.
 */
data class EditState(
    val rotation: Int = 0,
    val flipHorizontal: Boolean = false,
    val flipVertical: Boolean = false,
    val cropLeft: Float = 0f,
    val cropTop: Float = 0f,
    val cropWidth: Float = 1f,
    val cropHeight: Float = 1f,
    val outputWidth: Int = 0,
    val outputHeight: Int = 0,
    val brightness: Int = 0,
    val contrast: Int = 100,
    val saturation: Int = 100,
    val blur: Int = 0,
    val text: String = ""
)
